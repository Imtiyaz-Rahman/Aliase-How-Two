# Docker Aliases

alias d='docker'                         # Docker command
alias dps='docker ps'                    # List running containers
alias dpsa='docker ps -a'                # List all containers
alias di='docker images'                 # List images
alias dex='docker exec -it'              # Execute command in container
alias dlogf='docker logs -f'             # Follow container logs
alias dstop='docker stop'                # Stop container
alias drm='docker rm'                    # Remove container
alias drmi='docker rmi'                  # Remove image
alias dc='docker-compose'                # Docker Compose command
alias dcup='docker-compose up -d'        # Start services in background
alias dclogs='docker-compose logs -f'    # Follow compose logs
alias dcrestart='docker-compose restart' # Restart services

